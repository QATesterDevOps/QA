Las pruebas E2E se han desarrollado con la herramienta cypress, los pasos a seguir fueron los siguientes:
1.- Ingresar a la pagina web "https://www.demoblaze.com/"
2.- Se escogio un telefono movil 
3.- Se agrego 1 telefono movil en el carro de compras
4.- Se escogio una lapto
5.- Se agrego 1 lapto en el carro de compras
6.- Se confirma las compras de los 2 productos
7.- Se ingreso los datos del cliente para la compra
8.- Se visualiza la confirmacion de la compra